const {DB} = require('./man/db.js');
var db1;
db1 = DB.load("myData", "Pnw-BytDE7nEivwtL6q9SRp22s4L_m2x0cF-tE026HCh0yHcbLLzjwb0eaqEtJAOgJOMCNv6hZxbMk4kqM1Gmw==");
db1["hello"] = "world";
console.log(db1["hello"]);

//# sourceMappingURL=main.js.map
