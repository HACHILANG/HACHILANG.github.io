
This is the offical account for The HACHI programming language. If you feel the need to email due to a bug or a major flaw. main.hachilang@gmail is your key.


<!-- instead of curl, we could always just have the nvm installation file preinstalled. !-->