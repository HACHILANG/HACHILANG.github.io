chmod +x installation/run.sh
chmod +x uninstall.sh
chmod +x hachi
chmod +x ./installation/nodechecker
