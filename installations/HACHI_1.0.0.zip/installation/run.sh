
mv ./HachiLang /
mv ./hachi /
echo "Do Not Delete this folder..."