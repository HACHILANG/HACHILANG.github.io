rm -rf /HachiLang
rm -rf /hachi