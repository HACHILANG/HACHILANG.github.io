const { createClient } = require("@supabase/supabase.js")
const supabase = createClient("https://mojjnytmllvpqawnzzul.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlhdCI6MTYyNTI1ODEzOSwiZXhwIjoxOTQwODM0MTM5fQ.00wx2jyHppsX4ySliA_MHLyEgITR8bot2iEuB4Hm1Y4")

